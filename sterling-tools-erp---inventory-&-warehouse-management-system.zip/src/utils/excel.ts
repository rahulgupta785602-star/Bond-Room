import * as XLSX from 'xlsx';
import { InventoryItem } from '../types/inventory';

// Normalize header key for flexible matching
const normalizeKey = (key: string): string => {
  return key.toLowerCase().replace(/[^a-z0-9]/g, '');
};

export const parseBondRoomExcel = async (file: File): Promise<InventoryItem[]> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const rawJson: any[] = XLSX.utils.sheet_to_json(worksheet, { defval: '' });

        if (!rawJson || rawJson.length === 0) {
          throw new Error('The imported Excel file is empty or has no readable rows.');
        }

        const items: InventoryItem[] = [];

        rawJson.forEach((row, index) => {
          // Map columns flexibly
          const mappedRow: { [cleanKey: string]: any } = {};
          Object.keys(row).forEach((origKey) => {
            mappedRow[normalizeKey(origKey)] = row[origKey];
          });

          // Product Code
          const productCode = (
            mappedRow['productcode'] ||
            mappedRow['itemcode'] ||
            mappedRow['partnumber'] ||
            mappedRow['partno'] ||
            mappedRow['code'] ||
            mappedRow['sku'] ||
            `ITEM-${index + 1}`
          )
            .toString()
            .trim();

          if (!productCode) return;

          // Description
          const description = (
            mappedRow['itemdescription'] ||
            mappedRow['description'] ||
            mappedRow['itemname'] ||
            mappedRow['partdescription'] ||
            mappedRow['desc'] ||
            'Industrial Fastener'
          )
            .toString()
            .trim();

          // OEM stock
          const oemQty = parseFloat(
            mappedRow['oemqty'] ||
            mappedRow['oemquantity'] ||
            mappedRow['oemstock'] ||
            mappedRow['oemavailableqty'] ||
            0
          ) || 0;

          const oemWt = parseFloat(
            mappedRow['oemwt'] ||
            mappedRow['oemweight'] ||
            mappedRow['oemavailablewt'] ||
            0
          ) || 0;

          const oemLoc = (
            mappedRow['oemlocation'] ||
            mappedRow['oemloc'] ||
            mappedRow['oembin'] ||
            'BR-RACK-01'
          ).toString().trim();

          // OEM Plastic Bin stock
          const binQty = parseFloat(
            mappedRow['oemplasticbinqty'] ||
            mappedRow['plasticbinqty'] ||
            mappedRow['binqty'] ||
            mappedRow['oemplasticbinavailableqty'] ||
            mappedRow['binavailableqty'] ||
            0
          ) || 0;

          const binWt = parseFloat(
            mappedRow['oemplasticbinwt'] ||
            mappedRow['plasticbinwt'] ||
            mappedRow['binwt'] ||
            mappedRow['oemplasticbinavailablewt'] ||
            0
          ) || 0;

          const binLoc = (
            mappedRow['oemplasticbinlocation'] ||
            mappedRow['plasticbinlocation'] ||
            mappedRow['binlocation'] ||
            mappedRow['binloc'] ||
            'PB-BIN-101'
          ).toString().trim();

          // Retail stock
          const retailQty = parseFloat(
            mappedRow['retailqty'] ||
            mappedRow['retailquantity'] ||
            mappedRow['retailstock'] ||
            mappedRow['retailavailableqty'] ||
            0
          ) || 0;

          const retailWt = parseFloat(
            mappedRow['retailwt'] ||
            mappedRow['retailweight'] ||
            mappedRow['retailavailablewt'] ||
            0
          ) || 0;

          const retailLoc = (
            mappedRow['retaillocation'] ||
            mappedRow['retailloc'] ||
            mappedRow['retailbin'] ||
            'RT-SHELF-01'
          ).toString().trim();

          // If master has direct Total Qty/Wt or calculated from 3 segregated categories
          const totalQty = oemQty + binQty + retailQty > 0
            ? oemQty + binQty + retailQty
            : parseFloat(mappedRow['totalavailableqty'] || mappedRow['totalqty'] || mappedRow['qty'] || 0) || 0;

          const totalWeight = oemWt + binWt + retailWt > 0
            ? Math.round((oemWt + binWt + retailWt) * 100) / 100
            : parseFloat(mappedRow['totalavailablewt'] || mappedRow['totalwt'] || mappedRow['weight'] || 0) || 0;

          items.push({
            productCode,
            description,
            totalQty,
            totalWeight,
            oem: {
              qty: oemQty,
              weight: oemWt,
              location: oemLoc,
            },
            oemBin: {
              qty: binQty,
              weight: binWt,
              location: binLoc,
            },
            retail: {
              qty: retailQty,
              weight: retailWt,
              location: retailLoc,
            },
            updatedAt: new Date().toISOString(),
          });
        });

        resolve(items);
      } catch (err) {
        reject(err);
      }
    };

    reader.onerror = (error) => reject(error);
    reader.readAsArrayBuffer(file);
  });
};

export const exportInventoryToExcel = (items: InventoryItem[], fileName = 'STL_Bond_Room_Master_Summary.xlsx') => {
  // Create workbook with Master sheet and separated category sheets
  const masterData = items.map((item) => ({
    'Product Code': item.productCode,
    'Item Description': item.description,
    'Total Available Qty': item.totalQty,
    'Total Available Wt (Kg)': item.totalWeight,
    'OEM Qty': item.oem.qty,
    'OEM Wt (Kg)': item.oem.weight,
    'OEM Location': item.oem.location,
    'OEM (Plastic Bin) Qty': item.oemBin.qty,
    'OEM (Plastic Bin) Wt (Kg)': item.oemBin.weight,
    'OEM (Plastic Bin) Location': item.oemBin.location,
    'Retail Qty': item.retail.qty,
    'Retail Wt (Kg)': item.retail.weight,
    'Retail Location': item.retail.location,
    'Last Updated': new Date(item.updatedAt).toLocaleString(),
  }));

  const oemData = items.map((item) => ({
    'Product Code': item.productCode,
    'Item Description': item.description,
    'Available Qty': item.oem.qty,
    'Available Wt (Kg)': item.oem.weight,
    'Location': item.oem.location,
  }));

  const oemBinData = items.map((item) => ({
    'Product Code': item.productCode,
    'Item Description': item.description,
    'Available Qty': item.oemBin.qty,
    'Available Wt (Kg)': item.oemBin.weight,
    'Location': item.oemBin.location,
  }));

  const retailData = items.map((item) => ({
    'Product Code': item.productCode,
    'Item Description': item.description,
    'Available Qty': item.retail.qty,
    'Available Wt (Kg)': item.retail.weight,
    'Location': item.retail.location,
  }));

  const wb = XLSX.utils.book_new();

  const wsMaster = XLSX.utils.json_to_sheet(masterData);
  const wsOem = XLSX.utils.json_to_sheet(oemData);
  const wsBin = XLSX.utils.json_to_sheet(oemBinData);
  const wsRetail = XLSX.utils.json_to_sheet(retailData);

  XLSX.utils.book_append_sheet(wb, wsMaster, 'Bond Room Master');
  XLSX.utils.book_append_sheet(wb, wsOem, 'OEM');
  XLSX.utils.book_append_sheet(wb, wsBin, 'OEM (Plastic Bin)');
  XLSX.utils.book_append_sheet(wb, wsRetail, 'Retail');

  XLSX.writeFile(wb, fileName);
};

export const downloadSampleMasterTemplate = () => {
  const sampleData = [
    {
      'Product Code': 'STL-HEX-M10-045',
      'Item Description': 'Hex Flange Bolt M10x1.5x45mm Gr 10.9',
      'OEM Qty': 12000,
      'OEM Wt (Kg)': 720,
      'OEM Location': 'BR-RACK-01A',
      'OEM (Plastic Bin) Qty': 5000,
      'OEM (Plastic Bin) Wt (Kg)': 300,
      'OEM (Plastic Bin) Location': 'PB-BIN-104',
      'Retail Qty': 3000,
      'Retail Wt (Kg)': 180,
      'Retail Location': 'RT-SHELF-02',
    },
    {
      'Product Code': 'STL-SOC-M08-030',
      'Item Description': 'Socket Head Cap Screw M8x1.25x30mm Gr 12.9',
      'OEM Qty': 9000,
      'OEM Wt (Kg)': 315,
      'OEM Location': 'BR-RACK-01B',
      'OEM (Plastic Bin) Qty': 4000,
      'OEM (Plastic Bin) Wt (Kg)': 140,
      'OEM (Plastic Bin) Location': 'PB-BIN-108',
      'Retail Qty': 2500,
      'Retail Wt (Kg)': 87.5,
      'Retail Location': 'RT-SHELF-05',
    },
  ];

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(sampleData);
  XLSX.utils.book_append_sheet(wb, ws, 'Template');
  XLSX.writeFile(wb, 'STL_Bond_Room_Master_Template.xlsx');
};

export interface MaterialInExcelRow {
  productCode: string;
  description: string;
  actualQty: number;
  location: string;
  typeOfPacking: 'OEM' | 'OEM (Plastic Bin)' | 'Retail';
}

export const parseMaterialInExcel = async (file: File): Promise<MaterialInExcelRow[]> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const rawJson: any[] = XLSX.utils.sheet_to_json(worksheet, { defval: '' });

        if (!rawJson || rawJson.length === 0) {
          throw new Error('The Material IN Excel file is empty.');
        }

        const rows: MaterialInExcelRow[] = [];

        rawJson.forEach((row, index) => {
          const mappedRow: { [cleanKey: string]: any } = {};
          Object.keys(row).forEach((origKey) => {
            mappedRow[normalizeKey(origKey)] = row[origKey];
          });

          const productCode = (
            mappedRow['productcode'] ||
            mappedRow['itemcode'] ||
            mappedRow['partnumber'] ||
            mappedRow['code'] ||
            `ITEM-${index + 1}`
          ).toString().trim();

          const description = (
            mappedRow['description'] ||
            mappedRow['itemdescription'] ||
            mappedRow['itemname'] ||
            'Fastener Component'
          ).toString().trim();

          const actualQty = parseFloat(
            mappedRow['actualqty'] ||
            mappedRow['qty'] ||
            mappedRow['quantity'] ||
            mappedRow['inqty'] ||
            0
          ) || 0;

          const location = (
            mappedRow['location'] ||
            mappedRow['loc'] ||
            mappedRow['rack'] ||
            mappedRow['bin'] ||
            'BR-GEN'
          ).toString().trim();

          const rawPacking = (
            mappedRow['typeofpacking'] ||
            mappedRow['packingtype'] ||
            mappedRow['packing'] ||
            mappedRow['type'] ||
            'OEM'
          ).toString().toLowerCase();

          let typeOfPacking: 'OEM' | 'OEM (Plastic Bin)' | 'Retail' = 'OEM';
          if (rawPacking.includes('bin') || rawPacking.includes('plastic')) {
            typeOfPacking = 'OEM (Plastic Bin)';
          } else if (rawPacking.includes('retail')) {
            typeOfPacking = 'Retail';
          }

          if (productCode && actualQty > 0) {
            rows.push({
              productCode,
              description,
              actualQty,
              location,
              typeOfPacking,
            });
          }
        });

        resolve(rows);
      } catch (err) {
        reject(err);
      }
    };

    reader.onerror = (error) => reject(error);
    reader.readAsArrayBuffer(file);
  });
};

export const downloadSampleMaterialInTemplate = () => {
  const sampleData = [
    {
      'Product Code': 'STL-HEX-M10-045',
      'Description': 'Hex Flange Bolt M10x1.5x45mm Gr 10.9',
      'Actual Qty': 2500,
      'Location': 'BR-RACK-01A',
      'Type of Packing': 'OEM',
    },
    {
      'Product Code': 'STL-SOC-M08-030',
      'Description': 'Socket Head Cap Screw M8x1.25x30mm Gr 12.9',
      'Actual Qty': 1000,
      'Location': 'PB-BIN-108',
      'Type of Packing': 'OEM (Plastic Bin)',
    },
    {
      'Product Code': 'STL-NUT-M10-FLG',
      'Description': 'Prevailing Torque Flange Nut M10 Zinc Yellow',
      'Actual Qty': 800,
      'Location': 'RT-SHELF-12',
      'Type of Packing': 'Retail',
    },
  ];

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(sampleData);
  XLSX.utils.book_append_sheet(wb, ws, 'Material_IN_Template');
  XLSX.writeFile(wb, 'STL_Material_IN_Bulk_Template.xlsx');
};
