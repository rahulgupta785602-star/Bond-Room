import { InventoryItem } from '../types/inventory';

export const INITIAL_INVENTORY: InventoryItem[] = [
  {
    productCode: 'STL-HEX-M10-045',
    description: 'Hex Flange Bolt M10x1.5x45mm Gr 10.9 Geomet 500B',
    totalQty: 24500,
    totalWeight: 1470.0,
    oem: {
      qty: 12500,
      weight: 750.0,
      location: 'BR-RACK-01A',
    },
    oemBin: {
      qty: 7000,
      weight: 420.0,
      location: 'PB-BIN-104',
    },
    retail: {
      qty: 5000,
      weight: 300.0,
      location: 'RT-SHELF-02',
    },
    updatedAt: new Date().toISOString(),
  },
  {
    productCode: 'STL-SOC-M08-030',
    description: 'Socket Head Cap Screw M8x1.25x30mm Gr 12.9 Black Oxide',
    totalQty: 18200,
    totalWeight: 637.0,
    oem: {
      qty: 9200,
      weight: 322.0,
      location: 'BR-RACK-01B',
    },
    oemBin: {
      qty: 6000,
      weight: 210.0,
      location: 'PB-BIN-108',
    },
    retail: {
      qty: 3000,
      weight: 105.0,
      location: 'RT-SHELF-05',
    },
    updatedAt: new Date().toISOString(),
  },
  {
    productCode: 'STL-WHL-M12-060',
    description: 'Automotive Wheel Stud Bolt M12x1.5x60mm Serrated Neck Gr 10.9',
    totalQty: 14000,
    totalWeight: 1190.0,
    oem: {
      qty: 8500,
      weight: 722.5,
      location: 'BR-RACK-02A',
    },
    oemBin: {
      qty: 3500,
      weight: 297.5,
      location: 'PB-BIN-202',
    },
    retail: {
      qty: 2000,
      weight: 170.0,
      location: 'RT-SHELF-09',
    },
    updatedAt: new Date().toISOString(),
  },
  {
    productCode: 'STL-NUT-M10-FLG',
    description: 'Prevailing Torque All-Metal Flange Nut M10x1.5 Zinc Yellow',
    totalQty: 32000,
    totalWeight: 640.0,
    oem: {
      qty: 18000,
      weight: 360.0,
      location: 'BR-RACK-03A',
    },
    oemBin: {
      qty: 9000,
      weight: 180.0,
      location: 'PB-BIN-301',
    },
    retail: {
      qty: 5000,
      weight: 100.0,
      location: 'RT-SHELF-12',
    },
    updatedAt: new Date().toISOString(),
  },
  {
    productCode: 'STL-ENG-M06-025',
    description: 'Cylinder Head Engine Bolt M6x1.0x25mm Gr 8.8 Dacromet 320',
    totalQty: 26000,
    totalWeight: 390.0,
    oem: {
      qty: 15000,
      weight: 225.0,
      location: 'BR-RACK-04A',
    },
    oemBin: {
      qty: 8000,
      weight: 120.0,
      location: 'PB-BIN-115',
    },
    retail: {
      qty: 3000,
      weight: 45.0,
      location: 'RT-SHELF-03',
    },
    updatedAt: new Date().toISOString(),
  },
  {
    productCode: 'STL-CHAS-M14-080',
    description: 'Chassis High Tensile Suspension Bolt M14x1.5x80mm Gr 10.9 Phosphate',
    totalQty: 9500,
    totalWeight: 1425.0,
    oem: {
      qty: 5500,
      weight: 825.0,
      location: 'BR-RACK-05B',
    },
    oemBin: {
      qty: 2500,
      weight: 375.0,
      location: 'PB-BIN-210',
    },
    retail: {
      qty: 1500,
      weight: 225.0,
      location: 'RT-SHELF-14',
    },
    updatedAt: new Date().toISOString(),
  },
  {
    productCode: 'STL-STUD-M08-040',
    description: 'Double Ended Exhaust Manifold Stud M8x1.25x40mm Copper Coated',
    totalQty: 11400,
    totalWeight: 319.2,
    oem: {
      qty: 6200,
      weight: 173.6,
      location: 'BR-RACK-02B',
    },
    oemBin: {
      qty: 3200,
      weight: 89.6,
      location: 'PB-BIN-119',
    },
    retail: {
      qty: 2000,
      weight: 56.0,
      location: 'RT-SHELF-07',
    },
    updatedAt: new Date().toISOString(),
  },
  {
    productCode: 'STL-PIN-D10-050',
    description: 'Precision Hardened Ground Dowel Pin 10mm x 50mm m6 Tolerance',
    totalQty: 7800,
    totalWeight: 241.8,
    oem: {
      qty: 4500,
      weight: 139.5,
      location: 'BR-RACK-06A',
    },
    oemBin: {
      qty: 2300,
      weight: 71.3,
      location: 'PB-BIN-305',
    },
    retail: {
      qty: 1000,
      weight: 31.0,
      location: 'RT-SHELF-18',
    },
    updatedAt: new Date().toISOString(),
  },
];
