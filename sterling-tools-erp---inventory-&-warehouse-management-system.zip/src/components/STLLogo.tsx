import React from 'react';

interface STLLogoProps {
  className?: string;
  size?: number | string;
}

export const STLLogo: React.FC<STLLogoProps> = ({ className = 'w-8 h-8', size }) => {
  return (
    <svg
      viewBox="0 0 200 230"
      className={className}
      style={size ? { width: size, height: size } : undefined}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-label="Sterling Tools Limited (STL) Logo"
    >
      {/* Outer Hexagonal Bolt Head in Red */}
      <polygon
        points="100,5 194,59 194,171 100,225 6,171 6,59"
        fill="#E31837"
      />

      {/* White Hexagonal Dividing Border */}
      <polygon
        points="100,26 175,69 175,161 100,204 25,161 25,69"
        fill="#0D0D11"
        stroke="#FFFFFF"
        strokeWidth="7"
        strokeLinejoin="round"
      />

      {/* Inner Black Hexagon Core */}
      <polygon
        points="100,31 170,72 170,158 100,199 30,158 30,72"
        fill="#0D0D11"
      />

      {/* Bold White STL Monogram */}
      <text
        x="100"
        y="126"
        textAnchor="middle"
        dominantBaseline="middle"
        fill="#FFFFFF"
        fontFamily="'Plus Jakarta Sans', 'Arial Black', Impact, sans-serif"
        fontSize="68"
        fontWeight="900"
        letterSpacing="-2px"
      >
        STL
      </text>
    </svg>
  );
};
