import React, { useState, useRef } from 'react';
import { 
  Building2, 
  LogOut, 
  Camera, 
  ChevronDown, 
  Layers, 
  Boxes, 
  Box, 
  ShoppingBag, 
  ArrowLeftRight,
  Database
} from 'lucide-react';
import { UserSession } from '../types/inventory';
import { STLLogo } from './STLLogo';

export type ActiveTab = 'bond_room' | 'oem' | 'oem_bin' | 'retail' | 'movement';

interface HeaderProps {
  session: UserSession;
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  onLogout: () => void;
  onUpdateAvatar: (dataUrl: string) => void;
  itemCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  session,
  activeTab,
  onSelectTab,
  onLogout,
  onUpdateAvatar,
  itemCount,
}) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Please upload an image file (PNG, JPG, WEBP).');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      onUpdateAvatar(result);
    };
    reader.readAsDataURL(file);
  };

  const tabs: { id: ActiveTab; label: string; icon: React.ReactNode }[] = [
    { id: 'bond_room', label: 'Bond Room Data (Master Summary)', icon: <Layers className="w-4 h-4" /> },
    { id: 'oem', label: 'OEM', icon: <Boxes className="w-4 h-4" /> },
    { id: 'oem_bin', label: 'OEM (Plastic Bin)', icon: <Box className="w-4 h-4" /> },
    { id: 'retail', label: 'Retail', icon: <ShoppingBag className="w-4 h-4" /> },
    { id: 'movement', label: 'Material Movement (IN / OUT Operations)', icon: <ArrowLeftRight className="w-4 h-4" /> },
  ];

  return (
    <header className="bg-[#0b223d] border-b border-[#163a63] text-white shadow-md sticky top-0 z-30 select-none">
      {/* Top Banner Row */}
      <div className="max-w-[1600px] mx-auto px-4 sm:px-6 py-2.5 flex items-center justify-between gap-4">
        
        {/* Left: Oracle ERP Brand & System Status */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="flex items-center gap-2 bg-[#122f52] px-2.5 py-1 rounded border border-[#1b4372]">
            <Database className="w-4 h-4 text-sky-400" />
            <span className="text-xs font-semibold tracking-wider text-sky-200">ORACLE EBS WMS</span>
            <span className="text-[10px] text-sky-400/80 font-mono">v12.2</span>
          </div>
          <span className="hidden lg:inline text-xs text-slate-400">
            Plant-01 &middot; Faridabad Facility
          </span>
        </div>

        {/* Top Center: Company Name & Official STL Logo */}
        <div className="flex items-center gap-3 text-center justify-center">
          <STLLogo className="w-9 h-10 shrink-0 drop-shadow-md hover:scale-105 transition-transform" />
          <div className="text-left">
            <h1 className="text-base sm:text-lg font-bold tracking-tight text-white flex items-center gap-2">
              Sterling Tools Limited
            </h1>
            <p className="text-[11px] text-slate-300 font-medium tracking-wide">
              Inventory & Warehouse Management System
            </p>
          </div>
        </div>

        {/* Top Right: User Profile Widget */}
        <div className="relative shrink-0">
          <div 
            onClick={() => setDropdownOpen(!dropdownOpen)}
            className="flex items-center gap-3 p-1.5 rounded-lg hover:bg-[#122f52] cursor-pointer transition-colors border border-transparent hover:border-[#1b4372]"
          >
            {/* Profile Image with subtle ring */}
            <div className="relative group">
              <div className="w-10 h-10 rounded-full overflow-hidden bg-slate-800 border-2 border-sky-400/80 shadow flex items-center justify-center text-slate-200 font-bold">
                {session.avatarUrl ? (
                  <img 
                    src={session.avatarUrl} 
                    alt={session.name} 
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <span className="text-sm bg-gradient-to-tr from-sky-600 to-indigo-600 w-full h-full flex items-center justify-center text-white">
                    RG
                  </span>
                )}
              </div>
              <button 
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  fileInputRef.current?.click();
                }}
                title="Change Photo"
                className="absolute -bottom-1 -right-1 bg-sky-500 hover:bg-sky-400 text-slate-950 rounded-full p-1 shadow-md opacity-80 group-hover:opacity-100 transition-opacity"
              >
                <Camera className="w-2.5 h-2.5 text-white" />
              </button>
            </div>

            {/* Profile Details: Name & Designation strictly right below */}
            <div className="text-left hidden sm:block">
              <div className="text-xs font-semibold text-white leading-tight flex items-center gap-1">
                <span>{session.name}</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </div>
              <div className="text-[11px] font-medium text-amber-300/90 leading-tight">
                {session.designation}
              </div>
            </div>
          </div>

          {/* Hidden File Input for Avatar Upload */}
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleImageUpload} 
            accept="image/*" 
            className="hidden" 
          />

          {/* Profile Dropdown Menu */}
          {dropdownOpen && (
            <div 
              className="absolute right-0 mt-2 w-72 bg-slate-900 border border-slate-700/80 rounded-xl shadow-2xl p-3 z-50 animate-in fade-in slide-in-from-top-2 text-slate-200 text-xs"
              onMouseLeave={() => setDropdownOpen(false)}
            >
              <div className="flex items-center gap-3 pb-3 mb-3 border-b border-slate-800">
                <div className="w-12 h-12 rounded-full overflow-hidden bg-slate-800 border-2 border-sky-400 flex items-center justify-center shrink-0">
                  {session.avatarUrl ? (
                    <img 
                      src={session.avatarUrl} 
                      alt={session.name} 
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <span className="text-base font-bold text-white bg-sky-600 w-full h-full flex items-center justify-center">
                      RG
                    </span>
                  )}
                </div>
                <div className="overflow-hidden">
                  <div className="font-semibold text-white text-sm truncate">{session.name}</div>
                  <div className="text-amber-300 text-xs font-medium">{session.designation}</div>
                  <div className="text-[11px] text-slate-400 font-mono truncate">{session.username}</div>
                </div>
              </div>

              {/* Upload Photo Button */}
              <button
                type="button"
                onClick={() => {
                  fileInputRef.current?.click();
                  setDropdownOpen(false);
                }}
                className="w-full py-2 px-3 mb-2 rounded-lg bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white flex items-center gap-2 transition-colors cursor-pointer"
              >
                <Camera className="w-4 h-4 text-sky-400" />
                <span>Upload / Change Profile Photo</span>
              </button>

              <div className="pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setDropdownOpen(false);
                    onLogout();
                  }}
                  className="w-full py-2 px-3 rounded-lg bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 hover:text-rose-200 flex items-center gap-2 transition-colors font-medium cursor-pointer"
                >
                  <LogOut className="w-4 h-4 text-rose-400" />
                  <span>Logout from Session</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Enterprise Navigation Tabs Bar */}
      <div className="bg-[#08182b] border-t border-[#122e4f] px-4 sm:px-6">
        <div className="max-w-[1600px] mx-auto flex items-center overflow-x-auto no-scrollbar gap-1">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => onSelectTab(tab.id)}
                className={`py-3 px-4 text-xs font-semibold whitespace-nowrap flex items-center gap-2 border-b-2 transition-all cursor-pointer ${
                  isActive
                    ? 'border-sky-400 text-white bg-[#102b4c]'
                    : 'border-transparent text-slate-300 hover:text-white hover:bg-[#0c223c]'
                }`}
              >
                <span className={isActive ? 'text-sky-400' : 'text-slate-400'}>
                  {tab.icon}
                </span>
                <span>{tab.label}</span>
                {tab.id === 'bond_room' && (
                  <span className="text-[10px] px-1.5 py-0.2 font-mono bg-sky-950 text-sky-300 border border-sky-800/80 rounded">
                    {itemCount} SKUs
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
