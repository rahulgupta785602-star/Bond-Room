import React, { useState, useMemo, useRef } from 'react';
import { 
  ArrowDownLeft, 
  ArrowUpRight, 
  CheckCircle2, 
  AlertCircle, 
  Boxes, 
  Box, 
  ShoppingBag, 
  FileSpreadsheet, 
  Upload, 
  FileDown, 
  History, 
  AlertTriangle,
  Search,
  PackageCheck,
  Send,
  Plus
} from 'lucide-react';
import { InventoryItem, MaterialMovementLog } from '../types/inventory';
import { 
  parseMaterialInExcel, 
  downloadSampleMaterialInTemplate 
} from '../utils/excel';

interface MaterialMovementTabProps {
  items: InventoryItem[];
  movementLogs: MaterialMovementLog[];
  onUpdateInventory: (updatedItems: InventoryItem[]) => void;
  onAddMovementLog: (log: MaterialMovementLog) => void;
  operatorName: string;
}

export const MaterialMovementTab: React.FC<MaterialMovementTabProps> = ({
  items,
  movementLogs,
  onUpdateInventory,
  onAddMovementLog,
  operatorName,
}) => {
  // Main mode toggle: OUT vs IN
  const [movementMode, setMovementMode] = useState<'OUT' | 'IN'>('OUT');

  // Sub-mode for MATERIAL IN: 'MANUAL' vs 'BULK'
  const [inSubMode, setInSubMode] = useState<'MANUAL' | 'BULK'>('MANUAL');

  // Notification message
  const [notification, setNotification] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  const showNotification = (type: 'success' | 'error', text: string) => {
    setNotification({ type, text });
    setTimeout(() => setNotification(null), 5000);
  };

  // ----------------------------------------------------
  // PART A: MATERIAL OUT STATE
  // ----------------------------------------------------
  const [outProductCode, setOutProductCode] = useState<string>(items[0]?.productCode || '');
  const [selectedPackingCategory, setSelectedPackingCategory] = useState<'OEM' | 'OEM_BIN' | 'RETAIL'>('OEM');
  const [outQtyInput, setOutQtyInput] = useState<string>('');
  
  // Zero Stock Confirmation Modal State
  const [isZeroModalOpen, setIsZeroModalOpen] = useState(false);

  // Active item for MATERIAL OUT
  const activeOutItem = useMemo(() => {
    return items.find((i) => i.productCode.toLowerCase() === outProductCode.trim().toLowerCase());
  }, [items, outProductCode]);

  // Current selected category stock details for OUT
  const selectedCategoryStock = useMemo(() => {
    if (!activeOutItem) return { qty: 0, weight: 0, location: '-' };
    if (selectedPackingCategory === 'OEM') return activeOutItem.oem;
    if (selectedPackingCategory === 'OEM_BIN') return activeOutItem.oemBin;
    return activeOutItem.retail;
  }, [activeOutItem, selectedPackingCategory]);

  const categoryNameReadable = {
    OEM: 'OEM',
    OEM_BIN: 'OEM (Plastic Bin)',
    RETAIL: 'Retail',
  }[selectedPackingCategory];

  // Handle Remove / Dispatch
  const handleDispatch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeOutItem) {
      showNotification('error', 'Please select a valid Product Code.');
      return;
    }

    const outQty = parseFloat(outQtyInput);
    if (isNaN(outQty) || outQty <= 0) {
      showNotification('error', 'Please enter a valid positive Out Qty.');
      return;
    }

    if (outQty > selectedCategoryStock.qty) {
      showNotification(
        'error',
        `Insufficient stock! Requested ${outQty.toLocaleString()} exceeds available ${selectedCategoryStock.qty.toLocaleString()} in ${categoryNameReadable}.`
      );
      return;
    }

    const prevQty = selectedCategoryStock.qty;
    const newQty = prevQty - outQty;

    // Weight delta calculation (proportional)
    const unitWt = prevQty > 0 ? selectedCategoryStock.weight / prevQty : 0;
    const newWt = Math.max(0, Math.round((selectedCategoryStock.weight - outQty * unitWt) * 10) / 10);

    const updatedItems = items.map((item) => {
      if (item.productCode !== activeOutItem.productCode) return item;

      const newOem = selectedPackingCategory === 'OEM'
        ? { ...item.oem, qty: newQty, weight: newWt }
        : item.oem;

      const newBin = selectedPackingCategory === 'OEM_BIN'
        ? { ...item.oemBin, qty: newQty, weight: newWt }
        : item.oemBin;

      const newRetail = selectedPackingCategory === 'RETAIL'
        ? { ...item.retail, qty: newQty, weight: newWt }
        : item.retail;

      const newTotalQty = newOem.qty + newBin.qty + newRetail.qty;
      const newTotalWt = Math.round((newOem.weight + newBin.weight + newRetail.weight) * 10) / 10;

      return {
        ...item,
        totalQty: newTotalQty,
        totalWeight: newTotalWt,
        oem: newOem,
        oemBin: newBin,
        retail: newRetail,
        updatedAt: new Date().toISOString(),
      };
    });

    onUpdateInventory(updatedItems);

    // Audit log
    onAddMovementLog({
      id: `MOV-${Date.now()}`,
      timestamp: new Date().toISOString(),
      type: 'OUT',
      productCode: activeOutItem.productCode,
      description: activeOutItem.description,
      packingType: categoryNameReadable as any,
      quantityDelta: -outQty,
      previousQty: prevQty,
      newQty,
      location: selectedCategoryStock.location,
      operator: operatorName,
      notes: `Dispatched ${outQty} PCS from ${categoryNameReadable}`,
    });

    setOutQtyInput('');
    showNotification(
      'success',
      `Successfully dispatched ${outQty.toLocaleString()} PCS of ${activeOutItem.productCode} from ${categoryNameReadable}. Remaining: ${newQty.toLocaleString()} PCS.`
    );
  };

  // Handle Zero Stock Confirmation
  const handleConfirmZeroStock = () => {
    if (!activeOutItem) return;

    const prevQty = selectedCategoryStock.qty;

    const updatedItems = items.map((item) => {
      if (item.productCode !== activeOutItem.productCode) return item;

      const newOem = selectedPackingCategory === 'OEM'
        ? { qty: 0, weight: 0, location: '-' }
        : item.oem;

      const newBin = selectedPackingCategory === 'OEM_BIN'
        ? { qty: 0, weight: 0, location: '-' }
        : item.oemBin;

      const newRetail = selectedPackingCategory === 'RETAIL'
        ? { qty: 0, weight: 0, location: '-' }
        : item.retail;

      const newTotalQty = newOem.qty + newBin.qty + newRetail.qty;
      const newTotalWt = Math.round((newOem.weight + newBin.weight + newRetail.weight) * 10) / 10;

      return {
        ...item,
        totalQty: newTotalQty,
        totalWeight: newTotalWt,
        oem: newOem,
        oemBin: newBin,
        retail: newRetail,
        updatedAt: new Date().toISOString(),
      };
    });

    onUpdateInventory(updatedItems);

    onAddMovementLog({
      id: `MOV-${Date.now()}`,
      timestamp: new Date().toISOString(),
      type: 'ZERO_STOCK',
      productCode: activeOutItem.productCode,
      description: activeOutItem.description,
      packingType: categoryNameReadable as any,
      quantityDelta: -prevQty,
      previousQty: prevQty,
      newQty: 0,
      location: '-',
      operator: operatorName,
      notes: `Physical item unavailable: Stock set to 0 and location cleared.`,
    });

    setIsZeroModalOpen(false);
    showNotification(
      'success',
      `Zero Stock applied! ${categoryNameReadable} stock for ${activeOutItem.productCode} has been set to 0 and location cleared.`
    );
  };

  // ----------------------------------------------------
  // PART B: MATERIAL IN STATE (Manual & Bulk)
  // ----------------------------------------------------
  const [inProductCode, setInProductCode] = useState<string>(items[0]?.productCode || '');
  const [inPackingType, setInPackingType] = useState<'OEM' | 'OEM_BIN' | 'RETAIL'>('OEM');
  const [inQtyInput, setInQtyInput] = useState<string>('');
  const [inLocationInput, setInLocationInput] = useState<string>('');

  const bulkFileInputRef = useRef<HTMLInputElement>(null);

  // Active item for MATERIAL IN (Manual)
  const activeInItem = useMemo(() => {
    return items.find((i) => i.productCode.toLowerCase() === inProductCode.trim().toLowerCase());
  }, [items, inProductCode]);

  // Before Qty for selected category
  const beforeQty = useMemo(() => {
    if (!activeInItem) return 0;
    if (inPackingType === 'OEM') return activeInItem.oem.qty;
    if (inPackingType === 'OEM_BIN') return activeInItem.oemBin.qty;
    return activeInItem.retail.qty;
  }, [activeInItem, inPackingType]);

  // Current location preview / default
  const currentLocation = useMemo(() => {
    if (!activeInItem) return '';
    if (inPackingType === 'OEM') return activeInItem.oem.location;
    if (inPackingType === 'OEM_BIN') return activeInItem.oemBin.location;
    return activeInItem.retail.location;
  }, [activeInItem, inPackingType]);

  // After Enter Qty live preview
  const parsedInQty = parseFloat(inQtyInput) || 0;
  const afterEnterQty = beforeQty + parsedInQty;

  const inCategoryNameReadable = {
    OEM: 'OEM',
    OEM_BIN: 'OEM (Plastic Bin)',
    RETAIL: 'Retail',
  }[inPackingType];

  // Handle Manual Stock In
  const handleManualStockIn = (e: React.FormEvent) => {
    e.preventDefault();

    const inQty = parseFloat(inQtyInput);
    if (isNaN(inQty) || inQty <= 0) {
      showNotification('error', 'Please enter a valid positive IN Qty.');
      return;
    }

    const code = inProductCode.trim();
    if (!code) {
      showNotification('error', 'Please provide a Product Code.');
      return;
    }

    const loc = inLocationInput.trim() || currentLocation || 'BR-GEN';

    // Check if item exists in inventory
    let itemExisted = false;
    let description = activeInItem?.description || 'Industrial Fastener Component';

    const updatedItems = items.map((item) => {
      if (item.productCode.toLowerCase() !== code.toLowerCase()) return item;
      itemExisted = true;

      // Estimate weight delta using average piece weight if exists
      const avgPieceWt = item.totalQty > 0 ? item.totalWeight / item.totalQty : 0.05;
      const additionalWt = Math.round(inQty * avgPieceWt * 10) / 10;

      const newOem = inPackingType === 'OEM'
        ? { qty: item.oem.qty + inQty, weight: item.oem.weight + additionalWt, location: loc }
        : item.oem;

      const newBin = inPackingType === 'OEM_BIN'
        ? { qty: item.oemBin.qty + inQty, weight: item.oemBin.weight + additionalWt, location: loc }
        : item.oemBin;

      const newRetail = inPackingType === 'RETAIL'
        ? { qty: item.retail.qty + inQty, weight: item.retail.weight + additionalWt, location: loc }
        : item.retail;

      return {
        ...item,
        totalQty: newOem.qty + newBin.qty + newRetail.qty,
        totalWeight: Math.round((newOem.weight + newBin.weight + newRetail.weight) * 10) / 10,
        oem: newOem,
        oemBin: newBin,
        retail: newRetail,
        updatedAt: new Date().toISOString(),
      };
    });

    // If item was not found, create a new master SKU
    if (!itemExisted) {
      const estimatedWeight = Math.round(inQty * 0.06 * 10) / 10;
      const newItem: InventoryItem = {
        productCode: code,
        description: 'New Master SKU Fastener',
        totalQty: inQty,
        totalWeight: estimatedWeight,
        oem: inPackingType === 'OEM' ? { qty: inQty, weight: estimatedWeight, location: loc } : { qty: 0, weight: 0, location: '-' },
        oemBin: inPackingType === 'OEM_BIN' ? { qty: inQty, weight: estimatedWeight, location: loc } : { qty: 0, weight: 0, location: '-' },
        retail: inPackingType === 'RETAIL' ? { qty: inQty, weight: estimatedWeight, location: loc } : { qty: 0, weight: 0, location: '-' },
        updatedAt: new Date().toISOString(),
      };
      updatedItems.unshift(newItem);
    }

    onUpdateInventory(updatedItems);

    onAddMovementLog({
      id: `MOV-${Date.now()}`,
      timestamp: new Date().toISOString(),
      type: 'IN',
      productCode: code,
      description,
      packingType: inCategoryNameReadable as any,
      quantityDelta: inQty,
      previousQty: beforeQty,
      newQty: afterEnterQty,
      location: loc,
      operator: operatorName,
      notes: `Manual Stock IN: +${inQty} PCS to ${inCategoryNameReadable} at ${loc}`,
    });

    setInQtyInput('');
    setInLocationInput('');
    showNotification(
      'success',
      `Stock IN recorded! Added ${inQty.toLocaleString()} PCS to ${code} (${inCategoryNameReadable}). New Balance: ${afterEnterQty.toLocaleString()} PCS.`
    );
  };

  // Handle Bulk Excel Import for MATERIAL IN
  const handleBulkExcelUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const rows = await parseMaterialInExcel(file);
      if (rows.length === 0) {
        throw new Error('No valid rows found in file.');
      }

      // Process rows into items copy
      const itemsMap = new Map<string, InventoryItem>();
      items.forEach((item) => itemsMap.set(item.productCode.toLowerCase(), { ...item }));

      let totalAddedQty = 0;

      rows.forEach((row) => {
        const key = row.productCode.toLowerCase();
        const existing = itemsMap.get(key);

        const packingKey = row.typeOfPacking === 'OEM (Plastic Bin)'
          ? 'oemBin'
          : row.typeOfPacking === 'Retail'
          ? 'retail'
          : 'oem';

        if (existing) {
          const currentStock = existing[packingKey];
          const unitWt = existing.totalQty > 0 ? existing.totalWeight / existing.totalQty : 0.05;
          const additionalWt = Math.round(row.actualQty * unitWt * 10) / 10;

          existing[packingKey] = {
            qty: currentStock.qty + row.actualQty,
            weight: currentStock.weight + additionalWt,
            location: row.location || currentStock.location || 'BR-GEN',
          };

          existing.totalQty = existing.oem.qty + existing.oemBin.qty + existing.retail.qty;
          existing.totalWeight = Math.round((existing.oem.weight + existing.oemBin.weight + existing.retail.weight) * 10) / 10;
          existing.updatedAt = new Date().toISOString();
        } else {
          // Create new
          const estWt = Math.round(row.actualQty * 0.05 * 10) / 10;
          const newItem: InventoryItem = {
            productCode: row.productCode,
            description: row.description,
            totalQty: row.actualQty,
            totalWeight: estWt,
            oem: packingKey === 'oem' ? { qty: row.actualQty, weight: estWt, location: row.location } : { qty: 0, weight: 0, location: '-' },
            oemBin: packingKey === 'oemBin' ? { qty: row.actualQty, weight: estWt, location: row.location } : { qty: 0, weight: 0, location: '-' },
            retail: packingKey === 'retail' ? { qty: row.actualQty, weight: estWt, location: row.location } : { qty: 0, weight: 0, location: '-' },
            updatedAt: new Date().toISOString(),
          };
          itemsMap.set(key, newItem);
        }

        totalAddedQty += row.actualQty;

        // Log entry
        onAddMovementLog({
          id: `MOV-BULK-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          timestamp: new Date().toISOString(),
          type: 'IN',
          productCode: row.productCode,
          description: row.description,
          packingType: row.typeOfPacking,
          quantityDelta: row.actualQty,
          previousQty: 0,
          newQty: row.actualQty,
          location: row.location,
          operator: operatorName,
          notes: `Bulk Excel Import from ${file.name}`,
        });
      });

      onUpdateInventory(Array.from(itemsMap.values()));
      showNotification(
        'success',
        `Bulk Import Successful! Processed ${rows.length} lines, added ${totalAddedQty.toLocaleString()} total units across categories.`
      );
    } catch (err: any) {
      showNotification('error', err.message || 'Failed to import Material IN Excel.');
    }

    if (e.target) {
      e.target.value = '';
    }
  };

  return (
    <div className="space-y-6">
      {/* Notifications */}
      {notification && (
        <div 
          role="alert"
          className={`p-3.5 rounded-lg text-xs flex items-center gap-2.5 border transition-all shadow-xs ${
            notification.type === 'success'
              ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
              : 'bg-rose-50 border-rose-300 text-rose-800'
          }`}
        >
          {notification.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          )}
          <span className="font-semibold">{notification.text}</span>
        </div>
      )}

      {/* Main Movement Header & Side-by-Side Mode Buttons */}
      <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
              Material Movement Operations
              <span className="text-[11px] font-semibold text-slate-600 bg-slate-100 border border-slate-200 px-2 py-0.5 rounded">
                Real-Time Stock Transactions
              </span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Execute outward dispatches, stock-in replenishment, and inventory reconciliation
            </p>
          </div>

          {/* Two Side-by-Side Main Buttons */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setMovementMode('OUT')}
              className={`flex-1 sm:flex-none py-2.5 px-6 rounded-lg text-xs font-bold tracking-wider uppercase flex items-center justify-center gap-2 transition-all cursor-pointer shadow-xs ${
                movementMode === 'OUT'
                  ? 'bg-rose-700 text-white ring-2 ring-rose-500/30'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300'
              }`}
            >
              <ArrowUpRight className="w-4 h-4" />
              <span>[ MATERIAL OUT ]</span>
            </button>

            <button
              type="button"
              onClick={() => setMovementMode('IN')}
              className={`flex-1 sm:flex-none py-2.5 px-6 rounded-lg text-xs font-bold tracking-wider uppercase flex items-center justify-center gap-2 transition-all cursor-pointer shadow-xs ${
                movementMode === 'IN'
                  ? 'bg-emerald-700 text-white ring-2 ring-emerald-500/30'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300'
              }`}
            >
              <ArrowDownLeft className="w-4 h-4" />
              <span>[ MATERIAL IN ]</span>
            </button>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* PART A: MATERIAL OUT PANEL                                                */}
      {/* ========================================================================= */}
      {movementMode === 'OUT' && (
        <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-6">
          <div className="border-b border-slate-200 pb-3 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded bg-rose-100 text-rose-700 flex items-center justify-center">
                <ArrowUpRight className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                Outward Material Dispatch
              </h3>
            </div>
            <span className="text-[11px] font-medium text-slate-500">
              Operator: <strong className="text-slate-800">{operatorName}</strong>
            </span>
          </div>

          {/* Step 1: Product Code Selection */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-700">
              1. Enter / Select Product Code:
            </label>
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  list="sku-datalist"
                  value={outProductCode}
                  onChange={(e) => setOutProductCode(e.target.value)}
                  placeholder="e.g. STL-HEX-M10-045"
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-300 focus:border-rose-500 focus:bg-white rounded-lg outline-none font-mono font-semibold text-slate-900"
                />
                <datalist id="sku-datalist">
                  {items.map((i) => (
                    <option key={i.productCode} value={i.productCode}>
                      {i.productCode} - {i.description}
                    </option>
                  ))}
                </datalist>
              </div>

              {/* Quick SKU dropdown select */}
              <select
                value={outProductCode}
                onChange={(e) => setOutProductCode(e.target.value)}
                className="py-2 px-3 text-xs bg-slate-50 border border-slate-300 focus:border-rose-500 rounded-lg text-slate-700 outline-none max-w-xs"
              >
                <option value="">Select from catalog...</option>
                {items.map((i) => (
                  <option key={i.productCode} value={i.productCode}>
                    {i.productCode}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Auto-Fetched Item Information */}
          {activeOutItem ? (
            <div className="space-y-4">
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div>
                  <div className="text-[11px] font-medium text-slate-500 uppercase">Item Description</div>
                  <div className="text-sm font-bold text-slate-900">{activeOutItem.description}</div>
                  <div className="text-xs text-slate-500 font-mono mt-0.5">
                    SKU: {activeOutItem.productCode}
                  </div>
                </div>
                <div className="text-left md:text-right shrink-0">
                  <div className="text-[11px] font-medium text-slate-500 uppercase">Total Available Stock</div>
                  <div className="text-xl font-bold font-mono tabular-nums text-slate-900">
                    {activeOutItem.totalQty.toLocaleString()} <span className="text-xs font-normal text-slate-500">PCS</span>
                  </div>
                  <div className="text-xs text-slate-500 font-mono">
                    Total Wt: {activeOutItem.totalWeight.toFixed(1)} Kg
                  </div>
                </div>
              </div>

              {/* Step 2: Split View Cards / Radio Checkboxes */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-2">
                  2. Select Packing Category for Dispatch:
                </label>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {/* Card 1: OEM */}
                  <div 
                    onClick={() => setSelectedPackingCategory('OEM')}
                    className={`p-3.5 rounded-lg border-2 cursor-pointer transition-all ${
                      selectedPackingCategory === 'OEM'
                        ? 'border-sky-600 bg-sky-50/50 shadow-xs'
                        : 'border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <input
                          type="radio"
                          id="cat-oem"
                          name="out-category"
                          checked={selectedPackingCategory === 'OEM'}
                          onChange={() => setSelectedPackingCategory('OEM')}
                          className="text-sky-600 focus:ring-sky-500"
                        />
                        <label htmlFor="cat-oem" className="text-xs font-bold text-slate-900 cursor-pointer">
                          OEM Stock
                        </label>
                      </div>
                      <Boxes className="w-4 h-4 text-sky-600" />
                    </div>
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between text-slate-600">
                        <span>Available Qty:</span>
                        <strong className="font-mono text-slate-900">{activeOutItem.oem.qty.toLocaleString()} PCS</strong>
                      </div>
                      <div className="flex justify-between text-slate-600">
                        <span>Location:</span>
                        <span className="font-mono bg-white px-1.5 py-0.5 rounded border border-slate-200 text-slate-800">
                          {activeOutItem.oem.location || '-'}
                        </span>
                      </div>
                      <div className="flex justify-between text-slate-500 text-[11px]">
                        <span>Weight:</span>
                        <span className="font-mono">{activeOutItem.oem.weight.toFixed(1)} Kg</span>
                      </div>
                    </div>
                  </div>

                  {/* Card 2: OEM Plastic Bin */}
                  <div 
                    onClick={() => setSelectedPackingCategory('OEM_BIN')}
                    className={`p-3.5 rounded-lg border-2 cursor-pointer transition-all ${
                      selectedPackingCategory === 'OEM_BIN'
                        ? 'border-indigo-600 bg-indigo-50/50 shadow-xs'
                        : 'border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <input
                          type="radio"
                          id="cat-bin"
                          name="out-category"
                          checked={selectedPackingCategory === 'OEM_BIN'}
                          onChange={() => setSelectedPackingCategory('OEM_BIN')}
                          className="text-indigo-600 focus:ring-indigo-500"
                        />
                        <label htmlFor="cat-bin" className="text-xs font-bold text-slate-900 cursor-pointer">
                          OEM (Plastic Bin) Stock
                        </label>
                      </div>
                      <Box className="w-4 h-4 text-indigo-600" />
                    </div>
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between text-slate-600">
                        <span>Available Qty:</span>
                        <strong className="font-mono text-slate-900">{activeOutItem.oemBin.qty.toLocaleString()} PCS</strong>
                      </div>
                      <div className="flex justify-between text-slate-600">
                        <span>Location:</span>
                        <span className="font-mono bg-white px-1.5 py-0.5 rounded border border-slate-200 text-slate-800">
                          {activeOutItem.oemBin.location || '-'}
                        </span>
                      </div>
                      <div className="flex justify-between text-slate-500 text-[11px]">
                        <span>Weight:</span>
                        <span className="font-mono">{activeOutItem.oemBin.weight.toFixed(1)} Kg</span>
                      </div>
                    </div>
                  </div>

                  {/* Card 3: Retail */}
                  <div 
                    onClick={() => setSelectedPackingCategory('RETAIL')}
                    className={`p-3.5 rounded-lg border-2 cursor-pointer transition-all ${
                      selectedPackingCategory === 'RETAIL'
                        ? 'border-amber-600 bg-amber-50/50 shadow-xs'
                        : 'border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <input
                          type="radio"
                          id="cat-retail"
                          name="out-category"
                          checked={selectedPackingCategory === 'RETAIL'}
                          onChange={() => setSelectedPackingCategory('RETAIL')}
                          className="text-amber-600 focus:ring-amber-500"
                        />
                        <label htmlFor="cat-retail" className="text-xs font-bold text-slate-900 cursor-pointer">
                          Retail Stock
                        </label>
                      </div>
                      <ShoppingBag className="w-4 h-4 text-amber-600" />
                    </div>
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between text-slate-600">
                        <span>Available Qty:</span>
                        <strong className="font-mono text-slate-900">{activeOutItem.retail.qty.toLocaleString()} PCS</strong>
                      </div>
                      <div className="flex justify-between text-slate-600">
                        <span>Location:</span>
                        <span className="font-mono bg-white px-1.5 py-0.5 rounded border border-slate-200 text-slate-800">
                          {activeOutItem.retail.location || '-'}
                        </span>
                      </div>
                      <div className="flex justify-between text-slate-500 text-[11px]">
                        <span>Weight:</span>
                        <span className="font-mono">{activeOutItem.retail.weight.toFixed(1)} Kg</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Step 3: Out Qty and Action Buttons */}
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 space-y-4">
                <form onSubmit={handleDispatch} className="flex flex-col sm:flex-row sm:items-end gap-3">
                  <div className="flex-1">
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      3. Enter Out Qty (PCS):
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        min="1"
                        max={selectedCategoryStock.qty}
                        value={outQtyInput}
                        onChange={(e) => setOutQtyInput(e.target.value)}
                        placeholder={`Max: ${selectedCategoryStock.qty}`}
                        className="w-full px-3 py-2 text-xs bg-white border border-slate-300 focus:border-rose-500 focus:ring-1 focus:ring-rose-500 rounded-lg outline-none font-mono font-bold text-slate-900"
                      />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[11px] font-mono text-slate-400">
                        PCS
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500 mt-1">
                      Selected source: <strong className="text-slate-800">{categoryNameReadable}</strong> &middot; Available: <span className="font-mono">{selectedCategoryStock.qty.toLocaleString()}</span>
                    </div>
                  </div>

                  {/* Button 1: Remove / Dispatch */}
                  <button
                    type="submit"
                    disabled={selectedCategoryStock.qty <= 0 || !outQtyInput}
                    className="py-2.5 px-5 bg-rose-600 hover:bg-rose-500 active:bg-rose-700 text-white rounded-lg text-xs font-bold tracking-wide flex items-center justify-center gap-2 shadow-xs transition-colors disabled:opacity-50 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Remove / Dispatch</span>
                  </button>

                  {/* Button 2: Zero Stock Feature */}
                  <button
                    type="button"
                    onClick={() => setIsZeroModalOpen(true)}
                    className="py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-amber-300 rounded-lg text-xs font-bold tracking-wide flex items-center justify-center gap-2 border border-slate-700 transition-colors cursor-pointer"
                  >
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                    <span>Zero Stock</span>
                  </button>
                </form>
              </div>
            </div>
          ) : (
            <div className="p-8 text-center border-2 border-dashed border-slate-200 rounded-lg text-slate-400 text-xs">
              Please enter or select a valid Product Code to load stock information.
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* PART B: MATERIAL IN PANEL (Bulk Import & Manual Input)                    */}
      {/* ========================================================================= */}
      {movementMode === 'IN' && (
        <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-6">
          <div className="border-b border-slate-200 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded bg-emerald-100 text-emerald-700 flex items-center justify-center">
                <ArrowDownLeft className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                Inward Stock Inwarding / Replenishment
              </h3>
            </div>

            {/* Sub-mode selector (Bulk vs Manual) */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg border border-slate-200">
              <button
                type="button"
                onClick={() => setInSubMode('MANUAL')}
                className={`py-1.5 px-3 rounded text-xs font-semibold transition-all cursor-pointer ${
                  inSubMode === 'MANUAL'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Manual Input Item
              </button>
              <button
                type="button"
                onClick={() => setInSubMode('BULK')}
                className={`py-1.5 px-3 rounded text-xs font-semibold transition-all cursor-pointer ${
                  inSubMode === 'BULK'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Bulk Import via Excel
              </button>
            </div>
          </div>

          {/* Submode 1: Manual Input Item */}
          {inSubMode === 'MANUAL' && (
            <form onSubmit={handleManualStockIn} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Product Code */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Product Code (Auto-fetches description):
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      list="sku-in-datalist"
                      value={inProductCode}
                      onChange={(e) => setInProductCode(e.target.value)}
                      placeholder="e.g. STL-HEX-M10-045"
                      required
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 focus:border-emerald-500 focus:bg-white rounded-lg outline-none font-mono font-semibold text-slate-900"
                    />
                    <datalist id="sku-in-datalist">
                      {items.map((i) => (
                        <option key={i.productCode} value={i.productCode}>
                          {i.productCode} - {i.description}
                        </option>
                      ))}
                    </datalist>
                  </div>
                  {activeInItem && (
                    <div className="text-[11px] text-slate-600 mt-1 font-medium truncate">
                      Item: <span className="text-slate-900 font-semibold">{activeInItem.description}</span>
                    </div>
                  )}
                </div>

                {/* Type of Packing dropdown */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Type of Packing:
                  </label>
                  <select
                    value={inPackingType}
                    onChange={(e) => setInPackingType(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 focus:border-emerald-500 rounded-lg text-slate-900 font-semibold outline-none"
                  >
                    <option value="OEM">OEM</option>
                    <option value="OEM_BIN">OEM (Plastic Bin)</option>
                    <option value="RETAIL">Retail</option>
                  </select>
                  <div className="text-[11px] text-slate-500 mt-1">
                    Target destination segment
                  </div>
                </div>

                {/* Before Qty (Current Realtime Stock) */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Before Qty (Current Stock):
                  </label>
                  <div className="px-3 py-2 text-xs bg-slate-100 border border-slate-200 rounded-lg font-mono font-bold text-slate-700 flex justify-between items-center">
                    <span>{beforeQty.toLocaleString()} PCS</span>
                    <span className="text-[10px] text-slate-500 uppercase font-sans font-medium">
                      Current in {inCategoryNameReadable}
                    </span>
                  </div>
                </div>

                {/* IN Qty Field */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    IN Qty (Enter Units to Add):
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={inQtyInput}
                    onChange={(e) => setInQtyInput(e.target.value)}
                    placeholder="Enter positive quantity..."
                    required
                    className="w-full px-3 py-2 text-xs bg-white border border-slate-300 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-lg outline-none font-mono font-bold text-slate-900"
                  />
                </div>

                {/* Live Preview: After Enter Qty (Formula: Before Qty + IN Qty) */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    After Enter Qty (Live Formula: Before + IN Qty):
                  </label>
                  <div className="px-3 py-2 text-xs bg-emerald-50 border border-emerald-300 rounded-lg font-mono font-bold text-emerald-900 flex justify-between items-center">
                    <span>{afterEnterQty.toLocaleString()} PCS</span>
                    <span className="text-[10px] text-emerald-700 font-sans font-semibold">
                      (+{parsedInQty.toLocaleString()} PCS)
                    </span>
                  </div>
                </div>

                {/* Location input field */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Location (Rack / Shelf / Bin ID):
                  </label>
                  <input
                    type="text"
                    value={inLocationInput}
                    onChange={(e) => setInLocationInput(e.target.value)}
                    placeholder={currentLocation || 'e.g. BR-RACK-01A'}
                    className="w-full px-3 py-2 text-xs bg-white border border-slate-300 focus:border-emerald-500 rounded-lg outline-none font-mono text-slate-900"
                  />
                  <div className="text-[11px] text-slate-500 mt-1">
                    Current location: <span className="font-mono">{currentLocation || 'Not set'}</span>
                  </div>
                </div>
              </div>

              {/* Submit Button */}
              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  className="py-2.5 px-6 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white rounded-lg text-xs font-bold tracking-wide flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>IN / Add Stock</span>
                </button>
              </div>
            </form>
          )}

          {/* Submode 2: Bulk Import via Excel */}
          {inSubMode === 'BULK' && (
            <div className="space-y-4">
              <input
                type="file"
                ref={bulkFileInputRef}
                onChange={handleBulkExcelUpload}
                accept=".xlsx, .xls, .csv"
                className="hidden"
              />

              <div className="border-2 border-dashed border-slate-300 hover:border-emerald-500 rounded-xl p-8 text-center bg-slate-50 transition-colors">
                <div className="w-12 h-12 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto mb-3">
                  <FileSpreadsheet className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-bold text-slate-900">
                  Bulk Material IN Excel Import
                </h4>
                <p className="text-xs text-slate-500 max-w-md mx-auto mt-1 mb-4">
                  Upload an Excel/CSV file with columns: <strong>Product Code</strong>, <strong>Description</strong>, <strong>Actual Qty</strong>, <strong>Location</strong>, and <strong>Type of Packing</strong> (OEM / OEM Plastic Bin / Retail).
                </p>

                <div className="flex items-center justify-center gap-3">
                  <button
                    type="button"
                    onClick={() => bulkFileInputRef.current?.click()}
                    className="py-2.5 px-5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg shadow-xs flex items-center gap-2 cursor-pointer transition-colors"
                  >
                    <Upload className="w-4 h-4" />
                    <span>Select & Import Excel</span>
                  </button>

                  <button
                    type="button"
                    onClick={downloadSampleMaterialInTemplate}
                    className="py-2.5 px-4 bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 text-xs font-medium rounded-lg flex items-center gap-2 cursor-pointer transition-colors"
                  >
                    <FileDown className="w-4 h-4 text-slate-500" />
                    <span>Download Blank Template</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* MOVEMENT ACTIVITY AUDIT TRAIL                                              */}
      {/* ========================================================================= */}
      <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden">
        <div className="p-3 sm:p-4 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-slate-600" />
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Recent Movement Transaction Log ({movementLogs.length})
            </h3>
          </div>
          <span className="text-[11px] text-slate-400">
            Real-time audit ledger
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-100 text-slate-700 border-b border-slate-200 text-[11px] font-semibold">
                <th className="py-2 px-3">Timestamp</th>
                <th className="py-2 px-3">Type</th>
                <th className="py-2 px-3">Product Code</th>
                <th className="py-2 px-3">Packing Category</th>
                <th className="py-2 px-3 text-right">Qty Delta</th>
                <th className="py-2 px-3 text-right">Resulting Balance</th>
                <th className="py-2 px-3 text-center">Location</th>
                <th className="py-2 px-3">Operator</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
              {movementLogs.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-6 text-center text-slate-400 font-sans">
                    No transactions recorded yet in this session.
                  </td>
                </tr>
              ) : (
                movementLogs.slice(0, 15).map((log) => {
                  const isOut = log.type === 'OUT';
                  const isZero = log.type === 'ZERO_STOCK';
                  return (
                    <tr key={log.id} className="hover:bg-slate-50">
                      <td className="py-2 px-3 text-slate-500 whitespace-nowrap">
                        {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </td>
                      <td className="py-2 px-3 font-sans font-semibold">
                        {isZero ? (
                          <span className="px-1.5 py-0.5 rounded text-[10px] bg-amber-100 text-amber-900 border border-amber-300">
                            ZERO STOCK
                          </span>
                        ) : isOut ? (
                          <span className="px-1.5 py-0.5 rounded text-[10px] bg-rose-100 text-rose-800 border border-rose-200">
                            DISPATCH OUT
                          </span>
                        ) : (
                          <span className="px-1.5 py-0.5 rounded text-[10px] bg-emerald-100 text-emerald-800 border border-emerald-200">
                            STOCK IN
                          </span>
                        )}
                      </td>
                      <td className="py-2 px-3 font-semibold text-slate-900">{log.productCode}</td>
                      <td className="py-2 px-3 font-sans text-slate-700">{log.packingType}</td>
                      <td className={`py-2 px-3 text-right font-bold ${
                        isZero ? 'text-amber-700' : isOut ? 'text-rose-600' : 'text-emerald-600'
                      }`}>
                        {log.quantityDelta > 0 ? `+${log.quantityDelta.toLocaleString()}` : log.quantityDelta.toLocaleString()}
                      </td>
                      <td className="py-2 px-3 text-right text-slate-900 font-bold">
                        {log.newQty.toLocaleString()}
                      </td>
                      <td className="py-2 px-3 text-center text-slate-600">{log.location}</td>
                      <td className="py-2 px-3 font-sans text-slate-600">{log.operator}</td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* ZERO STOCK POPUP CONFIRMATION MODAL                                        */}
      {/* ========================================================================= */}
      {isZeroModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl border border-slate-300 shadow-2xl max-w-md w-full p-6 text-left animate-in fade-in zoom-in-95">
            <div className="flex items-start gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-base font-bold text-slate-950">
                  Zero Stock Confirmation
                </h4>
                <p className="text-xs text-slate-600 mt-1">
                  Physical reconciliation action requested.
                </p>
              </div>
            </div>

            {/* Exact required text */}
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3.5 mb-5 text-xs text-amber-900 font-semibold">
              Are you sure you want to set this stock to zero?
            </div>

            <div className="text-xs text-slate-600 space-y-1 mb-6 bg-slate-50 p-3 rounded-lg border border-slate-200">
              <div className="flex justify-between">
                <span>SKU Code:</span>
                <strong className="font-mono text-slate-900">{activeOutItem?.productCode}</strong>
              </div>
              <div className="flex justify-between">
                <span>Packing Category:</span>
                <strong className="text-slate-900">{categoryNameReadable}</strong>
              </div>
              <div className="flex justify-between">
                <span>Current Available Qty:</span>
                <span className="font-mono font-bold text-rose-700">{selectedCategoryStock.qty.toLocaleString()} PCS</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>Resulting Action:</span>
                <span>Stock set to 0 and location cleared to "-"</span>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setIsZeroModalOpen(false)}
                className="py-2 px-4 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-100 border border-slate-300 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmZeroStock}
                className="py-2 px-4 rounded-lg text-xs font-bold text-white bg-rose-600 hover:bg-rose-500 active:bg-rose-700 transition-colors cursor-pointer shadow-xs"
              >
                Yes, Set Stock to Zero
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
