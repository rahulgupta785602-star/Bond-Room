import React, { useState } from 'react';
import { 
  Search, 
  Download, 
  Boxes, 
  Box, 
  ShoppingBag, 
  MapPin, 
  AlertTriangle,
  CheckCircle2
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { InventoryItem } from '../types/inventory';

interface CategoryTabProps {
  categoryKey: 'oem' | 'oem_bin' | 'retail';
  items: InventoryItem[];
}

export const CategoryTab: React.FC<CategoryTabProps> = ({ categoryKey, items }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const categoryMeta = {
    oem: {
      title: 'OEM Inventory Segment',
      subtitle: 'Original Equipment Manufacturer palletized & carton inventory',
      tag: 'Tier-1 Direct OEM Dispatch',
      icon: <Boxes className="w-5 h-5 text-sky-600" />,
      accentColor: 'sky',
      badgeBg: 'bg-sky-50 text-sky-800 border-sky-200',
      getData: (item: InventoryItem) => item.oem,
      fileName: 'STL_OEM_Stock_Export.xlsx',
    },
    oem_bin: {
      title: 'OEM (Plastic Bin) Segment',
      subtitle: 'Line-side returnable ESD & plastic bin stock for assembly lines',
      tag: 'Kanban Assembly Line Bins',
      icon: <Box className="w-5 h-5 text-indigo-600" />,
      accentColor: 'indigo',
      badgeBg: 'bg-indigo-50 text-indigo-800 border-indigo-200',
      getData: (item: InventoryItem) => item.oemBin,
      fileName: 'STL_OEM_Plastic_Bin_Stock_Export.xlsx',
    },
    retail: {
      title: 'Retail & Aftermarket Segment',
      subtitle: 'Commercial distributor packaging, small blister packs & shelf stock',
      tag: 'Dealer / Aftermarket Network',
      icon: <ShoppingBag className="w-5 h-5 text-amber-600" />,
      accentColor: 'amber',
      badgeBg: 'bg-amber-50 text-amber-800 border-amber-200',
      getData: (item: InventoryItem) => item.retail,
      fileName: 'STL_Retail_Stock_Export.xlsx',
    },
  }[categoryKey];

  // Map items to category projection
  const categoryRows = items.map((item) => {
    const stock = categoryMeta.getData(item);
    return {
      productCode: item.productCode,
      description: item.description,
      qty: stock.qty,
      weight: stock.weight,
      location: stock.location,
    };
  });

  // Filter
  const filteredRows = categoryRows.filter((row) => {
    const term = searchTerm.toLowerCase();
    return (
      row.productCode.toLowerCase().includes(term) ||
      row.description.toLowerCase().includes(term) ||
      row.location.toLowerCase().includes(term)
    );
  });

  // Aggregates
  const totalQty = categoryRows.reduce((acc, r) => acc + r.qty, 0);
  const totalWeight = Math.round(categoryRows.reduce((acc, r) => acc + r.weight, 0) * 10) / 10;
  const zeroStockCount = categoryRows.filter((r) => r.qty === 0).length;
  const distinctLocations = new Set(categoryRows.map((r) => r.location).filter(Boolean)).size;

  const handleExport = () => {
    const exportData = filteredRows.map((r) => ({
      'Product Code': r.productCode,
      'Item Description': r.description,
      'Available Qty': r.qty,
      'Available Wt (Kg)': r.weight,
      'Location': r.location,
    }));

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(exportData);
    XLSX.utils.book_append_sheet(wb, ws, categoryMeta.title);
    XLSX.writeFile(wb, categoryMeta.fileName);
  };

  return (
    <div className="space-y-4">
      {/* Header bar */}
      <div className="bg-white border border-slate-200 rounded-lg p-3 sm:p-4 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-center shrink-0">
            {categoryMeta.icon}
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
              {categoryMeta.title}
              <span className={`text-[11px] font-semibold border px-2 py-0.5 rounded ${categoryMeta.badgeBg}`}>
                {categoryMeta.tag}
              </span>
            </h2>
            <p className="text-xs text-slate-500">
              {categoryMeta.subtitle}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleExport}
          className="py-2 px-3 bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Download className="w-3.5 h-3.5 text-slate-600" />
          <span>Export Category to Excel</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white border border-slate-200 rounded-lg p-3">
          <div className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Available Category Qty</div>
          <div className="text-xl font-bold text-slate-900 font-mono tabular-nums mt-0.5">
            {totalQty.toLocaleString()} <span className="text-xs font-normal text-slate-500">PCS</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Ready for dispatch</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-3">
          <div className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Available Category Wt</div>
          <div className="text-xl font-bold text-slate-900 font-mono tabular-nums mt-0.5">
            {totalWeight.toLocaleString()} <span className="text-xs font-normal text-slate-500">KG</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Net stock weight</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-3">
          <div className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Active Locations</div>
          <div className="text-xl font-bold text-sky-900 font-mono tabular-nums mt-0.5">
            {distinctLocations}
          </div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
            <MapPin className="w-3 h-3 text-sky-500" />
            <span>Assigned racks & bins</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-3">
          <div className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Zero Stock SKUs</div>
          <div className={`text-xl font-bold font-mono tabular-nums mt-0.5 ${zeroStockCount > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
            {zeroStockCount}
          </div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
            {zeroStockCount > 0 ? (
              <>
                <AlertTriangle className="w-3 h-3 text-rose-500" />
                <span>Requires restocking</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                <span>All items in stock</span>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Real-time search filter */}
      <div className="bg-white border border-slate-200 rounded-lg p-3 flex items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by Product Code, Description, or Location..."
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-250 focus:border-sky-500 focus:bg-white rounded-md outline-none transition-colors"
          />
        </div>

        <div className="text-xs text-slate-500 font-medium">
          Showing <strong className="text-slate-800">{filteredRows.length}</strong> of {categoryRows.length} items
        </div>
      </div>

      {/* Category Table */}
      <div className="bg-white border border-slate-200 rounded-lg shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#0e2746] text-white border-b border-[#1c4472]">
                <th className="py-2.5 px-3 font-semibold border-r border-[#1c4472] whitespace-nowrap">
                  Product Code
                </th>
                <th className="py-2.5 px-3 font-semibold border-r border-[#1c4472] min-w-[280px]">
                  Description
                </th>
                <th className="py-2.5 px-3 font-semibold text-right border-r border-[#1c4472] whitespace-nowrap">
                  Available Qty (PCS)
                </th>
                <th className="py-2.5 px-3 font-semibold text-right border-r border-[#1c4472] whitespace-nowrap">
                  Available Wt (Kg)
                </th>
                <th className="py-2.5 px-3 font-semibold text-center whitespace-nowrap">
                  Location
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredRows.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-slate-400">
                    No items found matching "{searchTerm}".
                  </td>
                </tr>
              ) : (
                filteredRows.map((row, idx) => {
                  const isZero = row.qty === 0;
                  return (
                    <tr 
                      key={row.productCode}
                      className={`hover:bg-sky-50/50 transition-colors ${
                        isZero ? 'bg-rose-50/30' : idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'
                      }`}
                    >
                      <td className="py-2.5 px-3 font-mono font-semibold text-sky-950 border-r border-slate-200 whitespace-nowrap">
                        {row.productCode}
                      </td>
                      <td className="py-2.5 px-3 text-slate-800 border-r border-slate-200 font-medium">
                        {row.description}
                      </td>
                      <td className={`py-2.5 px-3 text-right font-mono font-bold tabular-nums border-r border-slate-200 ${
                        isZero ? 'text-rose-600' : 'text-slate-900'
                      }`}>
                        {row.qty.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-600 border-r border-slate-200">
                        {row.weight.toFixed(1)}
                      </td>
                      <td className="py-2.5 px-3 text-center font-mono">
                        <span className="text-[11px] bg-slate-100 text-slate-800 font-medium px-2 py-0.5 rounded border border-slate-250">
                          {row.location || '-'}
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
