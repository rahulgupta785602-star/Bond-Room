import React, { useState, useRef } from 'react';
import { 
  FileSpreadsheet, 
  Download, 
  Upload, 
  Search, 
  RefreshCw, 
  CheckCircle2, 
  AlertCircle,
  Database,
  Layers,
  Sparkles,
  FileDown
} from 'lucide-react';
import { InventoryItem } from '../types/inventory';
import { 
  parseBondRoomExcel, 
  exportInventoryToExcel, 
  downloadSampleMasterTemplate 
} from '../utils/excel';

interface BondRoomTabProps {
  items: InventoryItem[];
  onImportMaster: (newItems: InventoryItem[]) => void;
  onResetDefault: () => void;
}

export const BondRoomTab: React.FC<BondRoomTabProps> = ({
  items,
  onImportMaster,
  onResetDefault,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [importStatus, setImportStatus] = useState<{
    type: 'success' | 'error' | 'loading' | null;
    message: string;
  }>({ type: null, message: '' });
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImportStatus({ type: 'loading', message: `Parsing and auto-segregating ${file.name}...` });

    try {
      const parsedItems = await parseBondRoomExcel(file);
      onImportMaster(parsedItems);
      setImportStatus({
        type: 'success',
        message: `Successfully imported & auto-segregated ${parsedItems.length} SKUs across OEM, OEM Plastic Bin, and Retail tabs.`,
      });
      // clear status after 5s
      setTimeout(() => {
        setImportStatus({ type: null, message: '' });
      }, 5000);
    } catch (err: any) {
      setImportStatus({
        type: 'error',
        message: err.message || 'Failed to read Excel file. Please check format.',
      });
    }

    if (e.target) {
      e.target.value = '';
    }
  };

  const handleExport = () => {
    exportInventoryToExcel(items, `STL_Bond_Room_Master_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  // Filter items
  const filteredItems = items.filter((item) => {
    const term = searchTerm.toLowerCase();
    return (
      item.productCode.toLowerCase().includes(term) ||
      item.description.toLowerCase().includes(term) ||
      item.oem.location.toLowerCase().includes(term) ||
      item.oemBin.location.toLowerCase().includes(term) ||
      item.retail.location.toLowerCase().includes(term)
    );
  });

  // Calculate aggregates
  const totalMasterQty = items.reduce((acc, i) => acc + i.totalQty, 0);
  const totalMasterWt = Math.round(items.reduce((acc, i) => acc + i.totalWeight, 0) * 10) / 10;
  const oemTotalQty = items.reduce((acc, i) => acc + i.oem.qty, 0);
  const binTotalQty = items.reduce((acc, i) => acc + i.oemBin.qty, 0);
  const retailTotalQty = items.reduce((acc, i) => acc + i.retail.qty, 0);

  return (
    <div className="space-y-4">
      {/* Top Action Bar with Oracle ERP styling */}
      <div className="bg-white border border-slate-200 rounded-lg p-3 sm:p-4 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        
        {/* Module Title & Subtitle */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-sky-50 text-sky-700 border border-sky-200 flex items-center justify-center shrink-0">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
              Bond Room Master Summary
              <span className="text-[11px] font-semibold text-sky-700 bg-sky-50 border border-sky-200 px-2 py-0.5 rounded">
                Consolidated Storage Matrix
              </span>
            </h2>
            <p className="text-xs text-slate-500">
              Master inventory ledger with automated cross-category segregation logic
            </p>
          </div>
        </div>

        {/* Action Controls: Dropdown / Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Hidden File Input */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".xlsx, .xls, .csv"
            className="hidden"
          />

          {/* Import / Export Menu */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setDropdownOpen(!dropdownOpen)}
              className="py-2 px-3.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              <span>Excel Import / Export</span>
            </button>

            {dropdownOpen && (
              <div 
                className="absolute right-0 mt-1 w-64 bg-white border border-slate-200 rounded-lg shadow-xl py-1 z-40 text-xs text-slate-700 divide-y divide-slate-100"
                onMouseLeave={() => setDropdownOpen(false)}
              >
                <div className="py-1">
                  <button
                    type="button"
                    onClick={() => {
                      setDropdownOpen(false);
                      fileInputRef.current?.click();
                    }}
                    className="w-full px-3 py-2 text-left hover:bg-sky-50 hover:text-sky-900 flex items-center gap-2 font-medium transition-colors cursor-pointer"
                  >
                    <Upload className="w-4 h-4 text-sky-600" />
                    <div>
                      <div className="font-semibold text-slate-900">Import BR Stock Summary Excel</div>
                      <div className="text-[11px] text-slate-500">Auto-segregates into OEM, Bin, Retail</div>
                    </div>
                  </button>
                </div>

                <div className="py-1">
                  <button
                    type="button"
                    onClick={() => {
                      setDropdownOpen(false);
                      handleExport();
                    }}
                    className="w-full px-3 py-2 text-left hover:bg-emerald-50 hover:text-emerald-900 flex items-center gap-2 font-medium transition-colors cursor-pointer"
                  >
                    <Download className="w-4 h-4 text-emerald-600" />
                    <div>
                      <div className="font-semibold text-slate-900">Export to Excel (.xlsx)</div>
                      <div className="text-[11px] text-slate-500">Download current multi-sheet data</div>
                    </div>
                  </button>
                </div>

                <div className="py-1">
                  <button
                    type="button"
                    onClick={() => {
                      setDropdownOpen(false);
                      downloadSampleMasterTemplate();
                    }}
                    className="w-full px-3 py-2 text-left hover:bg-slate-50 text-slate-600 flex items-center gap-2 transition-colors cursor-pointer"
                  >
                    <FileDown className="w-4 h-4 text-slate-500" />
                    <span>Download Blank Sample Template</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Quick Direct Buttons */}
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="py-2 px-3 bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Import Excel"
          >
            <Upload className="w-3.5 h-3.5 text-sky-600" />
            <span className="hidden sm:inline">Import Excel</span>
          </button>

          <button
            type="button"
            onClick={handleExport}
            className="py-2 px-3 bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Export Excel"
          >
            <Download className="w-3.5 h-3.5 text-emerald-600" />
            <span className="hidden sm:inline">Export Excel</span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (window.confirm('Reset inventory data back to Sterling Tools default demo dataset?')) {
                onResetDefault();
              }
            }}
            className="py-2 px-2.5 bg-white hover:bg-slate-50 border border-slate-200 text-slate-500 hover:text-slate-700 rounded-lg text-xs transition-colors cursor-pointer"
            title="Reset to default data"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Auto-Segregation Banner / Notification */}
      {importStatus.type && (
        <div
          role="alert"
          className={`p-3 rounded-lg text-xs flex items-center gap-2 border transition-all ${
            importStatus.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : importStatus.type === 'error'
              ? 'bg-rose-50 border-rose-200 text-rose-800'
              : 'bg-sky-50 border-sky-200 text-sky-800'
          }`}
        >
          {importStatus.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />}
          {importStatus.type === 'error' && <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />}
          {importStatus.type === 'loading' && <RefreshCw className="w-4 h-4 text-sky-600 animate-spin shrink-0" />}
          <span className="font-medium">{importStatus.message}</span>
        </div>
      )}

      {/* KPI Metric Summary Strip (Oracle Dashboard Style) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-white border border-slate-200 rounded-lg p-3">
          <div className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Active SKUs</div>
          <div className="text-xl font-bold text-slate-900 font-mono tabular-nums mt-0.5">
            {items.length}
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <Database className="w-3 h-3 text-sky-500" />
            <span>Master Catalog</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-3">
          <div className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Total Available Qty</div>
          <div className="text-xl font-bold text-sky-900 font-mono tabular-nums mt-0.5">
            {totalMasterQty.toLocaleString()} <span className="text-xs font-normal text-slate-500">PCS</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Gross warehouse stock
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-3">
          <div className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Total Available Wt</div>
          <div className="text-xl font-bold text-emerald-900 font-mono tabular-nums mt-0.5">
            {totalMasterWt.toLocaleString()} <span className="text-xs font-normal text-slate-500">KG</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Total metric mass
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-3">
          <div className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Auto Segregation Split</div>
          <div className="text-xs font-semibold text-slate-700 mt-1 flex items-center justify-between">
            <span>OEM: <strong className="font-mono text-sky-700">{oemTotalQty.toLocaleString()}</strong></span>
            <span>Bin: <strong className="font-mono text-indigo-700">{binTotalQty.toLocaleString()}</strong></span>
          </div>
          <div className="text-xs font-semibold text-slate-700 mt-0.5">
            <span>Retail: <strong className="font-mono text-amber-700">{retailTotalQty.toLocaleString()}</strong></span>
          </div>
        </div>
      </div>

      {/* Real-time Search and Filter Bar */}
      <div className="bg-white border border-slate-200 rounded-lg p-3 flex items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by Product Code, Description, or Location..."
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-250 focus:border-sky-500 focus:bg-white rounded-md outline-none transition-colors"
          />
        </div>

        <div className="text-xs text-slate-500 font-medium">
          Showing <strong className="text-slate-800">{filteredItems.length}</strong> of {items.length} records
        </div>
      </div>

      {/* Master Consolidated Table */}
      <div className="bg-white border border-slate-200 rounded-lg shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            {/* Table Header with Grouped Headings */}
            <thead>
              <tr className="bg-[#0e2746] text-white border-b border-[#1c4472]">
                <th rowSpan={2} className="py-2.5 px-3 font-semibold text-left border-r border-[#1c4472] whitespace-nowrap">
                  Product Code
                </th>
                <th rowSpan={2} className="py-2.5 px-3 font-semibold text-left border-r border-[#1c4472] min-w-[200px]">
                  Item Description
                </th>
                <th colSpan={2} className="py-2 px-3 font-semibold text-center border-r border-[#1c4472] bg-[#14355d]">
                  Total Master Inventory
                </th>
                <th colSpan={3} className="py-2 px-3 font-semibold text-center border-r border-[#1c4472] bg-[#102d4f]">
                  OEM Stock
                </th>
                <th colSpan={3} className="py-2 px-3 font-semibold text-center border-r border-[#1c4472] bg-[#14355d]">
                  OEM (Plastic Bin) Stock
                </th>
                <th colSpan={3} className="py-2 px-3 font-semibold text-center bg-[#102d4f]">
                  Retail Stock
                </th>
              </tr>
              <tr className="bg-[#122e4f] text-slate-200 text-[11px] border-b border-slate-300">
                {/* Total */}
                <th className="py-1.5 px-2.5 text-right font-medium border-r border-[#1c4472] whitespace-nowrap">
                  Total Qty
                </th>
                <th className="py-1.5 px-2.5 text-right font-medium border-r border-[#1c4472] whitespace-nowrap">
                  Total Wt (Kg)
                </th>
                {/* OEM */}
                <th className="py-1.5 px-2.5 text-right font-medium border-r border-[#1c4472] whitespace-nowrap">
                  Qty
                </th>
                <th className="py-1.5 px-2.5 text-right font-medium border-r border-[#1c4472] whitespace-nowrap">
                  Wt (Kg)
                </th>
                <th className="py-1.5 px-2.5 text-center font-medium border-r border-[#1c4472] whitespace-nowrap">
                  Location
                </th>
                {/* OEM Bin */}
                <th className="py-1.5 px-2.5 text-right font-medium border-r border-[#1c4472] whitespace-nowrap">
                  Qty
                </th>
                <th className="py-1.5 px-2.5 text-right font-medium border-r border-[#1c4472] whitespace-nowrap">
                  Wt (Kg)
                </th>
                <th className="py-1.5 px-2.5 text-center font-medium border-r border-[#1c4472] whitespace-nowrap">
                  Location
                </th>
                {/* Retail */}
                <th className="py-1.5 px-2.5 text-right font-medium border-r border-[#1c4472] whitespace-nowrap">
                  Qty
                </th>
                <th className="py-1.5 px-2.5 text-right font-medium border-r border-[#1c4472] whitespace-nowrap">
                  Wt (Kg)
                </th>
                <th className="py-1.5 px-2.5 text-center font-medium whitespace-nowrap">
                  Location
                </th>
              </tr>
            </thead>

            {/* Table Body */}
            <tbody className="divide-y divide-slate-200">
              {filteredItems.length === 0 ? (
                <tr>
                  <td colSpan={13} className="py-8 text-center text-slate-400">
                    No matching items found for "{searchTerm}".
                  </td>
                </tr>
              ) : (
                filteredItems.map((item, idx) => (
                  <tr 
                    key={item.productCode} 
                    className={`hover:bg-sky-50/60 transition-colors ${idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'}`}
                  >
                    {/* Product Code */}
                    <td className="py-2 px-3 font-mono font-semibold text-sky-950 border-r border-slate-200 whitespace-nowrap">
                      {item.productCode}
                    </td>

                    {/* Description */}
                    <td className="py-2 px-3 text-slate-800 border-r border-slate-200">
                      {item.description}
                    </td>

                    {/* Total Available Qty */}
                    <td className="py-2 px-2.5 text-right font-mono font-bold tabular-nums text-slate-900 border-r border-slate-200 bg-sky-50/20">
                      {item.totalQty.toLocaleString()}
                    </td>

                    {/* Total Available Wt */}
                    <td className="py-2 px-2.5 text-right font-mono tabular-nums text-slate-700 border-r border-slate-200 bg-sky-50/20">
                      {item.totalWeight.toFixed(1)}
                    </td>

                    {/* OEM Stock: Qty, Wt, Loc */}
                    <td className="py-2 px-2.5 text-right font-mono tabular-nums text-slate-800 border-r border-slate-200">
                      {item.oem.qty.toLocaleString()}
                    </td>
                    <td className="py-2 px-2.5 text-right font-mono tabular-nums text-slate-600 border-r border-slate-200">
                      {item.oem.weight.toFixed(1)}
                    </td>
                    <td className="py-2 px-2.5 text-center font-mono text-slate-600 border-r border-slate-200">
                      <span className="text-[11px] bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded border border-slate-250">
                        {item.oem.location || '-'}
                      </span>
                    </td>

                    {/* OEM Bin Stock: Qty, Wt, Loc */}
                    <td className="py-2 px-2.5 text-right font-mono tabular-nums text-indigo-900 border-r border-slate-200">
                      {item.oemBin.qty.toLocaleString()}
                    </td>
                    <td className="py-2 px-2.5 text-right font-mono tabular-nums text-slate-600 border-r border-slate-200">
                      {item.oemBin.weight.toFixed(1)}
                    </td>
                    <td className="py-2 px-2.5 text-center font-mono text-slate-600 border-r border-slate-200">
                      <span className="text-[11px] bg-indigo-50 text-indigo-700 px-1.5 py-0.5 rounded border border-indigo-200">
                        {item.oemBin.location || '-'}
                      </span>
                    </td>

                    {/* Retail Stock: Qty, Wt, Loc */}
                    <td className="py-2 px-2.5 text-right font-mono tabular-nums text-amber-900 border-r border-slate-200">
                      {item.retail.qty.toLocaleString()}
                    </td>
                    <td className="py-2 px-2.5 text-right font-mono tabular-nums text-slate-600 border-r border-slate-200">
                      {item.retail.weight.toFixed(1)}
                    </td>
                    <td className="py-2 px-2.5 text-center font-mono text-slate-600">
                      <span className="text-[11px] bg-amber-50 text-amber-700 px-1.5 py-0.5 rounded border border-amber-200">
                        {item.retail.location || '-'}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
