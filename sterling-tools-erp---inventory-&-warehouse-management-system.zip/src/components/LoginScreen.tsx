import React, { useState } from 'react';
import { Lock, User, ShieldCheck, AlertCircle, ArrowRight } from 'lucide-react';
import { UserSession } from '../types/inventory';
import { STLLogo } from './STLLogo';

interface LoginScreenProps {
  onLoginSuccess: (session: UserSession) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLoginSuccess }) => {
  const [username, setUsername] = useState('Rahulgupta@stl');
  const [password, setPassword] = useState('Rahul@#stl');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setIsSubmitting(true);

    setTimeout(() => {
      // Strict credentials check
      const trimmedUser = username.trim();
      const trimmedPass = password.trim();

      if (trimmedUser === 'Rahulgupta@stl' && trimmedPass === 'Rahul@#stl') {
        const existingAvatar = localStorage.getItem('stl_user_avatar');
        const session: UserSession = {
          username: 'Rahulgupta@stl',
          name: 'Rahul Gupta',
          designation: 'MIS Executive',
          avatarUrl: existingAvatar || null,
          loginTime: new Date().toISOString(),
        };
        localStorage.setItem('stl_session', JSON.stringify(session));
        onLoginSuccess(session);
      } else {
        setErrorMessage('Wrong input / Invalid Credentials');
      }
      setIsSubmitting(false);
    }, 250);
  };

  const handleFillDemo = () => {
    setUsername('Rahulgupta@stl');
    setPassword('Rahul@#stl');
    setErrorMessage(null);
  };

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col justify-between relative overflow-hidden font-sans select-none">
      {/* Background architectural grid pattern */}
      <div 
        className="absolute inset-0 opacity-10 pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(#38bdf8 1px, transparent 1px), radial-gradient(#38bdf8 1px, #0f172a 1px)`,
          backgroundSize: '40px 40px',
          backgroundPosition: '0 0, 20px 20px'
        }}
      />

      {/* Corporate Top Strip */}
      <header className="relative z-10 w-full px-6 py-4 flex items-center justify-between border-b border-slate-800 bg-slate-950/80 backdrop-blur-sm">
        <div className="flex items-center gap-3">
          <STLLogo className="w-9 h-10 shrink-0 drop-shadow-md" />
          <div>
            <div className="text-white font-bold tracking-tight text-base flex items-center gap-2">
              Sterling Tools Limited
              <span className="text-[10px] tracking-wider uppercase font-semibold text-sky-400 bg-sky-950/70 border border-sky-800/60 px-1.5 py-0.5 rounded">
                EBS 12.2
              </span>
            </div>
            <div className="text-xs text-slate-400">Inventory & Warehouse Management System</div>
          </div>
        </div>
        <div className="hidden sm:flex items-center gap-2 text-xs text-slate-400">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Oracle ERP Secured Enterprise Portal</span>
        </div>
      </header>

      {/* Main Login Card */}
      <div className="relative z-10 flex-1 flex items-center justify-center p-4 sm:p-6">
        <div className="w-full max-w-md bg-slate-950/90 border border-slate-800 rounded-xl shadow-2xl p-6 sm:p-8 backdrop-blur-md">
          {/* Card Header with prominent STL logo */}
          <div className="text-center mb-6">
            <div className="flex justify-center mb-3">
              <STLLogo className="w-16 h-18 drop-shadow-xl hover:scale-105 transition-transform" />
            </div>
            <h1 className="text-xl font-bold text-white tracking-tight">System Authentication</h1>
            <p className="text-xs text-slate-400 mt-1">
              Sign in with your corporate credentials to access Bond Room operations
            </p>
          </div>

          {/* Explicit Error Banner */}
          {errorMessage && (
            <div 
              role="alert" 
              className="mb-5 p-3 rounded-lg bg-rose-950/60 border border-rose-500/50 flex items-start gap-2.5 text-rose-200 text-xs animate-shake"
            >
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold">{errorMessage}</span>
                <p className="text-rose-300/80 text-[11px] mt-0.5">
                  Please verify your username and password or click Demo Fill below.
                </p>
              </div>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Username / Corporate Email
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                  <User className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Rahulgupta@stl"
                  required
                  autoFocus
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-900 border border-slate-750 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 rounded-lg text-sm text-white placeholder-slate-500 outline-none transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  required
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-900 border border-slate-750 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 rounded-lg text-sm text-white placeholder-slate-500 outline-none transition-colors"
                />
              </div>
            </div>

            {/* Quick Helper Credentials note */}
            <div className="flex items-center justify-between text-xs pt-1">
              <span className="text-slate-400">Default Authorized:</span>
              <button
                type="button"
                onClick={handleFillDemo}
                className="text-sky-400 hover:text-sky-300 font-medium underline underline-offset-2 transition-colors"
              >
                Auto-Fill Authorized Creds
              </button>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full mt-2 py-2.5 px-4 bg-sky-600 hover:bg-sky-500 active:bg-sky-700 text-white rounded-lg text-sm font-semibold tracking-wide flex items-center justify-center gap-2 shadow-lg shadow-sky-600/30 transition-all disabled:opacity-50 cursor-pointer"
            >
              {isSubmitting ? (
                <span>Authenticating...</span>
              ) : (
                <>
                  <span>Sign In to ERP Portal</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Credentials Info Box */}
          <div className="mt-6 pt-5 border-t border-slate-800 text-xs text-slate-400 space-y-1 bg-slate-900/60 -mx-6 -mb-6 p-4 rounded-b-xl">
            <div className="font-medium text-slate-300 flex items-center justify-between">
              <span>Required Credentials:</span>
              <span className="text-[11px] text-slate-500">Plant-01 Warehouse</span>
            </div>
            <div className="font-mono text-[11px] text-sky-300 flex justify-between">
              <span>User: <strong className="text-white">Rahulgupta@stl</strong></span>
              <span>Pass: <strong className="text-white">Rahul@#stl</strong></span>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="relative z-10 w-full px-6 py-3 border-t border-slate-800/80 bg-slate-950/80 text-center text-xs text-slate-500">
        Sterling Tools Limited &middot; Automotive Cold Forged Fasteners Division &middot; Bond Room Control System
      </footer>
    </div>
  );
};
