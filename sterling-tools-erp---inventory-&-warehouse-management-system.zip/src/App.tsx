/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { InventoryItem, MaterialMovementLog, UserSession } from './types/inventory';
import { INITIAL_INVENTORY } from './data/initialData';
import { LoginScreen } from './components/LoginScreen';
import { Header, ActiveTab } from './components/Header';
import { BondRoomTab } from './components/BondRoomTab';
import { CategoryTab } from './components/CategoryTab';
import { MaterialMovementTab } from './components/MaterialMovementTab';
import { STLLogo } from './components/STLLogo';

export default function App() {
  // 1. Session State (Stored in LocalStorage)
  const [session, setSession] = useState<UserSession | null>(() => {
    try {
      const stored = localStorage.getItem('stl_session');
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });

  // 2. Navigation Active Tab
  const [activeTab, setActiveTab] = useState<ActiveTab>('bond_room');

  // 3. Inventory State (Stored in LocalStorage)
  const [items, setItems] = useState<InventoryItem[]>(() => {
    try {
      const stored = localStorage.getItem('stl_inventory');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error('Error loading inventory from localStorage:', e);
    }
    return INITIAL_INVENTORY;
  });

  // 4. Movement Logs (Stored in LocalStorage)
  const [movementLogs, setMovementLogs] = useState<MaterialMovementLog[]>(() => {
    try {
      const stored = localStorage.getItem('stl_movement_logs');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.error('Error loading logs from localStorage:', e);
    }
    // Initial sample transaction
    return [
      {
        id: 'MOV-INIT-01',
        timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
        type: 'IN',
        productCode: 'STL-HEX-M10-045',
        description: 'Hex Flange Bolt M10x1.5x45mm Gr 10.9 Geomet 500B',
        packingType: 'OEM',
        quantityDelta: 2500,
        previousQty: 10000,
        newQty: 12500,
        location: 'BR-RACK-01A',
        operator: 'Rahul Gupta',
        notes: 'Cold Forging Plant Batch #CF-2026-88 Received',
      },
      {
        id: 'MOV-INIT-02',
        timestamp: new Date(Date.now() - 3600000 * 5).toISOString(),
        type: 'OUT',
        productCode: 'STL-NUT-M10-FLG',
        description: 'Prevailing Torque All-Metal Flange Nut M10x1.5 Zinc Yellow',
        packingType: 'OEM (Plastic Bin)',
        quantityDelta: -1000,
        previousQty: 10000,
        newQty: 9000,
        location: 'PB-BIN-301',
        operator: 'Rahul Gupta',
        notes: 'Dispatched to Maruti Suzuki Line-2 Sub-Assembly',
      },
    ];
  });

  // Persist items to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('stl_inventory', JSON.stringify(items));
    } catch (e) {
      console.error('Error persisting inventory:', e);
    }
  }, [items]);

  // Persist movement logs to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('stl_movement_logs', JSON.stringify(movementLogs));
    } catch (e) {
      console.error('Error persisting logs:', e);
    }
  }, [movementLogs]);

  // Handlers
  const handleLoginSuccess = (newSession: UserSession) => {
    setSession(newSession);
  };

  const handleLogout = () => {
    localStorage.removeItem('stl_session');
    setSession(null);
  };

  const handleUpdateAvatar = (dataUrl: string) => {
    try {
      localStorage.setItem('stl_user_avatar', dataUrl);
      if (session) {
        const updated = { ...session, avatarUrl: dataUrl };
        setSession(updated);
        localStorage.setItem('stl_session', JSON.stringify(updated));
      }
    } catch (e) {
      console.error('Avatar save failed:', e);
    }
  };

  const handleImportMaster = (newItems: InventoryItem[]) => {
    setItems(newItems);
  };

  const handleResetDefault = () => {
    setItems(INITIAL_INVENTORY);
    localStorage.setItem('stl_inventory', JSON.stringify(INITIAL_INVENTORY));
  };

  const handleAddMovementLog = (log: MaterialMovementLog) => {
    setMovementLogs((prev) => [log, ...prev]);
  };

  // If not logged in, render strict login system
  if (!session) {
    return <LoginScreen onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans text-slate-800">
      {/* Oracle ERP Enterprise Header */}
      <Header
        session={session}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onLogout={handleLogout}
        onUpdateAvatar={handleUpdateAvatar}
        itemCount={items.length}
      />

      {/* Main Workspace Body */}
      <main className="flex-1 max-w-[1600px] w-full mx-auto p-4 sm:p-6 space-y-6">
        {/* Tab 1: Bond Room Data (Master Summary) */}
        {activeTab === 'bond_room' && (
          <BondRoomTab
            items={items}
            onImportMaster={handleImportMaster}
            onResetDefault={handleResetDefault}
          />
        )}

        {/* Tab 2: OEM */}
        {activeTab === 'oem' && (
          <CategoryTab categoryKey="oem" items={items} />
        )}

        {/* Tab 3: OEM (Plastic Bin) */}
        {activeTab === 'oem_bin' && (
          <CategoryTab categoryKey="oem_bin" items={items} />
        )}

        {/* Tab 4: Retail */}
        {activeTab === 'retail' && (
          <CategoryTab categoryKey="retail" items={items} />
        )}

        {/* Tab 5: Material Movement (IN / OUT Operations) */}
        {activeTab === 'movement' && (
          <MaterialMovementTab
            items={items}
            movementLogs={movementLogs}
            onUpdateInventory={setItems}
            onAddMovementLog={handleAddMovementLog}
            operatorName={session.name}
          />
        )}
      </main>

      {/* Enterprise System Footer */}
      <footer className="border-t border-slate-200 bg-white py-3 px-6 text-center text-xs text-slate-500">
        <div className="max-w-[1600px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <STLLogo className="w-4 h-4.5" />
            <span className="font-semibold text-slate-700">Sterling Tools Limited</span>
            <span>&middot;</span>
            <span>Bond Room Control System (BR-CS)</span>
          </div>
          <div className="text-[11px] text-slate-400 font-mono">
            Active Session: <strong className="text-slate-600 font-sans">{session.username}</strong> ({session.designation})
          </div>
        </div>
      </footer>
    </div>
  );
}
