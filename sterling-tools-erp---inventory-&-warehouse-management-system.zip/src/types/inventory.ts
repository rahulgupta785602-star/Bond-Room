export type PackingType = 'OEM' | 'OEM_BIN' | 'RETAIL';

export interface CategoryStock {
  qty: number;
  weight: number; // in Kg
  location: string;
}

export interface InventoryItem {
  productCode: string;
  description: string;
  totalQty: number;
  totalWeight: number; // in Kg
  oem: CategoryStock;
  oemBin: CategoryStock;
  retail: CategoryStock;
  updatedAt: string;
}

export interface MaterialMovementLog {
  id: string;
  timestamp: string;
  type: 'IN' | 'OUT' | 'ZERO_STOCK';
  productCode: string;
  description: string;
  packingType: 'OEM' | 'OEM (Plastic Bin)' | 'Retail';
  quantityDelta: number;
  previousQty: number;
  newQty: number;
  location: string;
  operator: string;
  notes?: string;
}

export interface UserSession {
  username: string;
  name: string;
  designation: string;
  avatarUrl: string | null;
  loginTime: string;
}
